# Language correction

The earlier archive sent on 2026-10-12 contained Polish-language documentation by mistake. This package is the English-language replacement.

The executable source files and regression tests are unchanged from the earlier package. Only the documentation filenames/content and the checksum manifest have changed.
