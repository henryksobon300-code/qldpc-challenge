"""Build a fresh-seed adversarial resweep queue from JSON/JSONL catalogues.

This does not perform the expensive distance search itself.  It solves the
pipeline-control problem: every non-exact claim is made visible, prioritized,
and emitted with a deterministic reason instead of disappearing into a flat d
field.  The output is intended to feed RIS/ISD, QDistEvol, MILP or SAT workers.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
from proof_gate import exact_distance, claimed_upper_bound


def _records(path):
    p = Path(path)
    txt = p.read_text(encoding="utf-8")
    if p.suffix == ".jsonl":
        for ln in txt.splitlines():
            if ln.strip():
                yield json.loads(ln)
        return
    obj = json.loads(txt)
    if isinstance(obj, list):
        yield from obj
    elif isinstance(obj, dict):
        # ilp_catalog style groups or a single record.
        if all(isinstance(v, list) for v in obj.values()):
            for group, arr in obj.items():
                for r in arr:
                    rr = dict(r); rr.setdefault("_group", group); yield rr
        else:
            yield obj


def priority(record):
    if exact_distance(record) is not None:
        return -1e9
    n, k = record.get("n", 0), record.get("k", 0)
    d = claimed_upper_bound(record) or 0
    score = 0.0
    if str(record.get("trust_level", "")).upper() == "PARTIAL": score += 100
    if record.get("publication_quality") is True: score += 80
    if record.get("deep_milp_time_s") in (None, 0): score += 40
    if n and d:
        score += 20 * (d / math.sqrt(n))
        score += min(40, (k * d * d / n) / 2)
    return score


def build_queue(path):
    out=[]
    for i,r in enumerate(_records(path)):
        if exact_distance(r) is not None:
            continue
        d = claimed_upper_bound(r)
        out.append({
            "priority": round(priority(r), 6),
            "source_index": i,
            "code_id": r.get("code_id") or r.get("bliss_hash") or r.get("label") or r.get("name"),
            "n": r.get("n"), "k": r.get("k"), "claimed_upper": d,
            "trust_level": r.get("trust_level"),
            "reason": "non_exact_distance_requires_fresh_independent_attack",
            "recommended_order": ["RIS_or_ISD_fresh_seed", "QDistEvol_or_other_independent_heuristic", "deep_MILP_or_SAT_if_still_relevant"],
        })
    out.sort(key=lambda x:x["priority"], reverse=True)
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("catalog")
    ap.add_argument("-o","--output")
    a=ap.parse_args()
    q=build_queue(a.catalog)
    txt="\n".join(json.dumps(x,sort_keys=True) for x in q)+("\n" if q else "")
    if a.output: Path(a.output).write_text(txt,encoding="utf-8")
    else: print(txt,end="")

if __name__=="__main__": main()
