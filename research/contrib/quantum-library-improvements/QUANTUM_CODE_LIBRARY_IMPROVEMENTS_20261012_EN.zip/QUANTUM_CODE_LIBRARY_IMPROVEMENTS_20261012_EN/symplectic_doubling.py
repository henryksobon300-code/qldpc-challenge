"""Clean-room symplectic-doubling utilities for stabilizer-code distance tooling.

For a general stabilizer check matrix S=(A|B), define a doubled CSS pair
    HX = [A | B]
    HZ = [B | A].
Isotropy of S implies HX @ HZ.T == 0 over GF(2).

A Pauli (x|z) maps to an X-type vector v=[x|z] of the doubled CSS code.
Commutation with S is exactly HZ v^T = 0.  Nontriviality modulo the original
stabilizer row space is exactly nontriviality modulo row(HX).

IMPORTANT: ordinary Hamming weight on v counts Y as 2, while Pauli weight counts
Y as 1.  Therefore a CSS search on the doubled code is a candidate generator /
upper-bound channel unless the search objective is explicitly changed to the
paired Pauli cost OR every found candidate is mapped back and re-scored.
"""
from __future__ import annotations
import numpy as np


def _bin(M):
    return np.asarray(M, dtype=np.uint8) & 1


def gf2_rank(M) -> int:
    A = _bin(M).copy()
    if A.ndim != 2:
        raise ValueError("matrix must be 2-D")
    r = 0
    for c in range(A.shape[1]):
        piv = np.flatnonzero(A[r:, c])
        if len(piv) == 0:
            continue
        p = r + int(piv[0])
        if p != r:
            A[[r, p]] = A[[p, r]]
        rows = np.flatnonzero(A[:, c])
        rows = rows[rows != r]
        if len(rows):
            A[rows] ^= A[r]
        r += 1
        if r == A.shape[0]:
            break
    return r


def in_rowspace(v, M) -> bool:
    M = _bin(M)
    v = _bin(v).reshape(1, -1)
    if M.shape[1] != v.shape[1]:
        raise ValueError("dimension mismatch")
    return gf2_rank(M) == gf2_rank(np.vstack([M, v]))


def is_isotropic(A, B) -> bool:
    A, B = _bin(A), _bin(B)
    if A.shape != B.shape:
        return False
    return not bool(((A @ B.T + B @ A.T) & 1).any())


def doubled_css(A, B):
    A, B = _bin(A), _bin(B)
    if A.shape != B.shape:
        raise ValueError("A and B must have the same shape")
    if not is_isotropic(A, B):
        raise ValueError("S=(A|B) is not an isotropic stabilizer check matrix")
    HX = np.concatenate([A, B], axis=1)
    HZ = np.concatenate([B, A], axis=1)
    # Defensive proof check.
    if ((HX @ HZ.T) & 1).any():
        raise AssertionError("doubling construction failed CSS commutation")
    return HX.astype(np.uint8), HZ.astype(np.uint8)


def pauli_to_doubled(x, z):
    x, z = _bin(x).ravel(), _bin(z).ravel()
    if x.shape != z.shape:
        raise ValueError("x and z must have the same length")
    return np.concatenate([x, z]).astype(np.uint8)


def doubled_to_pauli(v):
    v = _bin(v).ravel()
    if len(v) % 2:
        raise ValueError("doubled vector length must be even")
    n = len(v) // 2
    return v[:n].copy(), v[n:].copy()


def pauli_weight(x, z) -> int:
    x, z = _bin(x).ravel(), _bin(z).ravel()
    if x.shape != z.shape:
        raise ValueError("x and z must have the same length")
    return int(np.count_nonzero(x | z))


def doubled_hamming_weight(v) -> int:
    return int(_bin(v).sum())


def commutes_with_stabilizer(x, z, A, B) -> bool:
    x, z = _bin(x).ravel(), _bin(z).ravel()
    A, B = _bin(A), _bin(B)
    syn = (A @ z + B @ x) & 1
    return not bool(syn.any())


def is_nontrivial_pauli(x, z, A, B) -> bool:
    if not commutes_with_stabilizer(x, z, A, B):
        return False
    S = np.concatenate([_bin(A), _bin(B)], axis=1)
    return not in_rowspace(pauli_to_doubled(x, z), S)


def is_nontrivial_doubled_x(v, A, B) -> bool:
    HX, HZ = doubled_css(A, B)
    v = _bin(v).ravel()
    if v.shape[0] != HX.shape[1]:
        return False
    if ((HZ @ v) & 1).any():
        return False
    return not in_rowspace(v, HX)


def map_and_rescore(v, A, B):
    """Validate a doubled X-logical, map it back, return Pauli-weight evidence."""
    if not is_nontrivial_doubled_x(v, A, B):
        raise ValueError("candidate is not a nontrivial doubled X-logical")
    x, z = doubled_to_pauli(v)
    if not is_nontrivial_pauli(x, z, A, B):
        raise AssertionError("doubling logical mapping invariant failed")
    return {
        "x": x,
        "z": z,
        "pauli_weight": pauli_weight(x, z),
        "doubled_hamming_weight": doubled_hamming_weight(v),
    }
