"""Hard consumer-side proof gate for quantum-code catalogue records.

The design goal is simple: an unproved distance must never silently turn into an
exact headline number merely because several heuristics agree.
"""
from __future__ import annotations
import math

PROOF_LABELS = {
    "exact_milp", "exact_enumeration", "exhaustive_hash",
    "self_dual_proof", "webster_proven_exact", "symplectic_low_d_proof",
    "lrat_unsat_plus_witness", "solver_proof",
}


def _sources(record):
    s = record.get("bound_sources", []) or []
    if isinstance(s, str):
        s = [s]
    extra = record.get("d_exactness_source")
    if extra:
        s = list(s) + ["external_exactness_source"]
    return list(s)


def exact_distance(record):
    """Return exact d or None. Fail closed on ambiguous legacy records."""
    dl, du = record.get("d_lower"), record.get("d_upper")
    src = _sources(record)
    if isinstance(dl, int) and isinstance(du, int) and dl == du:
        if any(x in PROOF_LABELS for x in src) or record.get("d_is_exact") is True:
            return dl
    # Legacy exact field is accepted only with an explicit exact flag.
    d = record.get("d")
    if isinstance(d, int) and record.get("d_is_exact") is True:
        return d
    return None


def claimed_upper_bound(record):
    du = record.get("d_upper")
    if isinstance(du, int) and du > 0:
        return du
    d = record.get("d")
    if isinstance(d, int) and d > 0:
        return d
    return None


def publication_label(record):
    d = exact_distance(record)
    if d is not None:
        return f"d={d}"
    u = claimed_upper_bound(record)
    return f"d<={u}" if u is not None else "d unknown"


def certified_fom(record):
    d = exact_distance(record)
    n, k = record.get("n"), record.get("k")
    if not (isinstance(d, int) and isinstance(n, int) and n > 0 and isinstance(k, int)):
        return None
    return k * d * d / n


def exploratory_fom(record):
    u = claimed_upper_bound(record)
    n, k = record.get("n"), record.get("k")
    if not (isinstance(u, int) and isinstance(n, int) and n > 0 and isinstance(k, int)):
        return None
    return k * u * u / n


def gate(record, purpose="headline"):
    """Return structured allow/refuse decision.

    headline/external_submission require exactness by default.
    research_triage may use an upper bound but the returned label remains <=.
    """
    exact = exact_distance(record)
    trust = str(record.get("trust_level", "")).upper()
    reasons = []
    if purpose in {"headline", "external_submission"}:
        if exact is None:
            reasons.append("distance_not_proved_exact")
        if trust == "PARTIAL":
            reasons.append("trust_level_PARTIAL")
    elif purpose == "research_triage":
        if claimed_upper_bound(record) is None:
            reasons.append("no_distance_evidence")
    else:
        raise ValueError("unknown purpose")
    return {
        "allow": not reasons,
        "purpose": purpose,
        "distance_label": publication_label(record),
        "exact_d": exact,
        "certified_fom": certified_fom(record),
        "exploratory_fom": exploratory_fom(record),
        "reasons": reasons,
    }
