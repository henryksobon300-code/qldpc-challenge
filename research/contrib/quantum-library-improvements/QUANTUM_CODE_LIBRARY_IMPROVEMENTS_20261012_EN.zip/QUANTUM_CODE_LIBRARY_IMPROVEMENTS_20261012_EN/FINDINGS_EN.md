# Quantum-code library audit — 2026-10-12

## Main finding

The largest current problem is not candidate generation itself, but the **proof flow from a candidate to the distance value `d` used for ranking**. In `qiskit-community/qcode-discovery`, there is still a live path where BP-OSD and shallow MILP may return similar values, while an unproven number can continue downstream as a practically used distance. Open issue #13 gives two real Campaign 7 cases that an independent refuter later reduced from `40 -> <=16` and `32 -> <=20`. Five additional PARTIAL records are still identified as requiring re-checking. This is a signal-quality problem in the discovery loop, not a cosmetic reporting issue.

At the same time, `unitaryfoundation/qldpc-challenge` already has several mechanisms that address exactly these error classes: fresh-seed standing resweeps, RIS/ISD, orbit folding over symmetries, symplectic doubling for non-CSS codes, exact SAT/MILP certification, and hard decomposability/direct-sum checks. In the current `qcode-discovery`, these ideas are already described in open issues #15–#18, but I did not find an open PR implementing doubling, RIS, a hard proof gate, or an automatic resweep.

## What is already solved upstream and should not be duplicated

1. The **row-space intersection invariant** from PR `unitaryfoundation/qldpc-challenge#2740` is already MERGED. Its diagnostic value is correct and it passed independent review. There is no reason to reimplement it.
2. **Direct-sum / connectivity in qldpc-challenge** is already a hard gate (`tanner_connected` + generator-basis-invariant `stabilizer_group_connected`). Issue #2942 confirmed 10 decomposable Campaign 4 records, but the maintainer pointed out that the current verifier already rejects them.
3. **Orbit-fold / symmetry-restricted distance refutation** is already present in the current `verify/heuristic_distance.py` in qldpc-challenge. This mechanism hit a blind spot of random ISD on codes whose logical operators are constant on subgroup cosets.
4. `qcode-discovery` already has **proof-aware distance schema v2** (`d_lower`, `d_upper`, `bound_sources`, with exactness only when supported by proof). The remaining problem is that not every consuming path is guaranteed to enforce this semantics.

## What is still worth implementing in qcode-discovery

### A. Hard proof gate at the publication/export boundary

Neither `PARTIAL` nor a bare `d_upper` should be copied into a table as `d=...`. Minimal rule:

- exact proof: `d=...` and certified FOM;
- no proof: `d<=...`, exploratory FOM only for triage;
- agreement between BP-OSD + QDistEvol + time-boxed MILP **does not create a lower bound**;
- automated external export should refuse without an explicit override.

Included here: `proof_gate.py` + tests.

### B. Standing adversarial resweep

Every non-EXACT record should periodically receive a fresh independent attack. Priority should go to PARTIAL records, published records, high `d/sqrt(n)`, lack of deep MILP, and high exploratory FOM. Included here: `resweep_queue.py`, which converts a JSON/JSONL catalog into such a priority queue.

### C. Symplectic doubling as a shared CSS/non-CSS backend

For a stabilizer `S=(A|B)`:

`HX'=[A|B]`, `HZ'=[B|A]`.

Isotropy `AB^T + BA^T = 0` gives CSS commutation. A Pauli `(x|z)` is a logical operator of the original code exactly when the corresponding vector `[x|z]` is an X-logical of the doubled CSS code, with the same row-space quotient. This allows the same linear-algebra tooling to be reused for CSS and non-CSS codes.

**Critical limitation:** ordinary Hamming weight in the `2n` space counts Y as 2, while Pauli weight counts Y as 1. Therefore doubled CSS without a paired-cost objective is a candidate generator / upper-bound channel, not an automatic exact solver for Pauli distance. The result must be mapped back and scored as `|x OR z|`, or the objective function must be modified accordingly.

Included here: `symplectic_doubling.py` with mapping validation and tests.

### D. RIS/ISD as a third independent channel

This remains the most obvious missing channel on the `qcode-discovery` side: issue #17 is open. qldpc-challenge shows in practice that RIS + pair combination + bit-packed GF(2) can find lighter logical operators that BP-OSD and shallow MILP miss. For qcode-discovery, the best role of RIS is as a **falsifier**, not a certifier. A found logical operator gives a hard upper bound; failure to find one proves nothing.

### E. Equivalence cache before the exact solver

A historical Campaign 4 result identified a class of six equivalent `[[288,12,12]]` codes: an exact solve of one representative can be transferred to the other five through an explicit weight-preserving permutation certificate. This suggests a permanent layer:

`canonicalize -> cluster -> solve representative -> verify transform -> propagate exactness`.

There is no reason to run six heavy exact solvers if five tasks are mathematically the same code up to permutation.

## Where the largest practical gain comes from

The highest-value ordering is not “an even stronger code generator”, but:

`candidate -> connectivity/direct-sum -> canonical/equivalence cache -> cheap structural invariants -> multi-method refutation (BP-OSD + QDistEvol + RIS/orbit) -> proof-aware interval [d_lower,d_upper] -> exact SAT/MILP only for finalists -> circuit/decoder/hardware evaluation`.

This reduces exact-solver cost, eliminates incorrect records before publication, and improves the signal on which the next search/generation iteration operates.

## Sources for the current state

- https://github.com/qiskit-community/qcode-discovery/issues/7
- https://github.com/qiskit-community/qcode-discovery/issues/13
- https://github.com/qiskit-community/qcode-discovery/issues/14
- https://github.com/qiskit-community/qcode-discovery/issues/15
- https://github.com/qiskit-community/qcode-discovery/issues/16
- https://github.com/qiskit-community/qcode-discovery/issues/17
- https://github.com/qiskit-community/qcode-discovery/issues/18
- https://github.com/qiskit-community/qcode-discovery/issues/19
- https://github.com/unitaryfoundation/qldpc-challenge/issues/2899
- https://github.com/unitaryfoundation/qldpc-challenge/issues/2942
- https://github.com/unitaryfoundation/qldpc-challenge/pull/2740
