from proof_gate import *


def test_partial_cannot_be_headline_exact():
    r={"n":360,"k":10,"d":40,"d_is_exact":False,"trust_level":"PARTIAL"}
    g=gate(r,"headline")
    assert not g["allow"]
    assert g["distance_label"]=="d<=40"
    assert g["certified_fom"] is None
    assert g["exploratory_fom"] is not None


def test_exact_record_is_allowed():
    r={"n":288,"k":12,"d":12,"d_lower":12,"d_upper":12,
       "d_is_exact":True,"bound_sources":["exact_milp"],"trust_level":"EXACT"}
    g=gate(r,"headline")
    assert g["allow"] and g["distance_label"]=="d=12"
    assert g["certified_fom"]==6.0


def test_heuristic_agreement_does_not_create_exactness():
    r={"n":100,"k":10,"d":8,"d_lower":0,"d_upper":8,
       "bound_sources":["bp_osd_heuristic","qdistevol_heuristic"],
       "d_is_exact":False}
    assert exact_distance(r) is None
    assert publication_label(r)=="d<=8"
