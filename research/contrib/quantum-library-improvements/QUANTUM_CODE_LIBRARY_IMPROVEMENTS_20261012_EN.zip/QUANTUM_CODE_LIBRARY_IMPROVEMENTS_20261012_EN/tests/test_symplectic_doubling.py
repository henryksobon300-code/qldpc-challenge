import numpy as np
from symplectic_doubling import *


def test_basic_mapping_and_css_commutation():
    A=np.array([[1,0]],dtype=np.uint8)
    B=np.array([[0,1]],dtype=np.uint8)  # generator X0 Z1
    HX,HZ=doubled_css(A,B)
    assert not ((HX@HZ.T)&1).any()
    x=np.array([1,0],dtype=np.uint8); z=np.array([0,0],dtype=np.uint8)
    v=pauli_to_doubled(x,z)
    assert is_nontrivial_pauli(x,z,A,B)
    assert is_nontrivial_doubled_x(v,A,B)
    r=map_and_rescore(v,A,B)
    assert r["pauli_weight"]==1
    assert r["doubled_hamming_weight"]==1


def test_y_rescoring_is_not_doubled_hamming_weight():
    A=np.array([[1,0]],dtype=np.uint8)
    B=np.array([[0,1]],dtype=np.uint8)
    # Y on qubit 1 plus a choice making it commute is not needed here; test cost mapping itself.
    x=np.array([1,0],dtype=np.uint8); z=np.array([1,0],dtype=np.uint8)
    v=pauli_to_doubled(x,z)
    assert pauli_weight(x,z)==1
    assert doubled_hamming_weight(v)==2


def test_non_isotropic_rejected():
    A=np.array([[1,0],[0,0]],dtype=np.uint8)
    B=np.array([[0,0],[1,0]],dtype=np.uint8)
    assert not is_isotropic(A,B)
    try:
        doubled_css(A,B)
    except ValueError:
        pass
    else:
        raise AssertionError("non-isotropic matrix was accepted")
