import json, tempfile
from pathlib import Path
from resweep_queue import build_queue


def test_queue_prioritizes_partial_and_skips_exact():
    rows=[
      {"code_id":"partial","n":360,"k":10,"d":40,"trust_level":"PARTIAL","d_is_exact":False},
      {"code_id":"other","n":180,"k":6,"d":21,"trust_level":"TRUSTED","d_is_exact":False},
      {"code_id":"exact","n":288,"k":12,"d":12,"d_is_exact":True},
    ]
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"x.jsonl"
        p.write_text("\n".join(json.dumps(x) for x in rows)+"\n")
        q=build_queue(p)
    assert [x["code_id"] for x in q]==["partial","other"]
