# Reference architecture for a QEC system / quantum computer

There is no single “best quantum code” independent of hardware. A code that wins for neutral atoms with spatial reconfiguration may lose on a superconducting chip with a local grid and a different error profile. The best architecture should therefore optimize a **portfolio of codes + compiler + decoder + syndrome circuitry**, rather than a single `[[n,k,d]]` tuple.

## 1. Unified CodeIR object

Every code should be stored in one typed record:

- stabilizer/symplectic matrix `S=(A|B)` as the general form;
- optional CSS view `HX,HZ`;
- `n,k`, check weights, connectivity, components;
- `d_lower`, `d_upper`, proof sources, witnesses;
- automorphisms, canonical fingerprint, equivalence certificates;
- physical layout, routing cost, syndrome-circuit description;
- decoder profile and logical-error-rate benchmark;
- logical-gate capabilities (transversal, lattice surgery, gauge fixing, etc.).

There should not be separate, inconsistent formats for “discovery”, “paper”, “board”, and “runtime”.

## 2. Discovery plane

The generator should not be rewarded with raw `k*d_est^2/n`. It should see an objective vector:

- rate / k;
- check weight and degree;
- connectivity / absence of direct sums;
- layout/routing cost;
- `d_lower` (proof) separately from `d_upper` (witness);
- decoder performance;
- circuit depth and measurement schedule;
- hardware-specific penalties.

A scalar score may be used for search, but the record must preserve the full Pareto vector so that one arbitrary weighting does not become “truth”.

## 3. Structural normalization plane

Before any expensive distance search:

1. GF(2) normalization and cancellation of repeated monomials;
2. connectivity / stabilizer-group connectivity;
3. canonical fingerprint and deduplication;
4. equivalence clustering + explicit transform certificate;
5. cheap invariants: rank, row-space intersection, weight profiles, girth, symmetries;
6. detection of constructions with known decomposition/subgroup structure.

## 4. Distance evidence plane

Every method has a role and must not impersonate another:

- BP-OSD / decoder residuals -> witness upper bound;
- QDistEvol -> witness upper bound;
- RIS/ISD -> witness upper bound;
- orbit/symmetry fold -> witness upper bound, often extremely effective;
- MILP incumbent -> witness upper bound;
- SAT/MILP UNSAT floor -> lower bound;
- exhaustive completion / proof certificate -> lower bound or exactness.

The ledger merges evidence only monotonically:

`d_lower = max(proven lower bounds)`

`d_upper = min(valid witness weights)`

A result becomes exact only when the interval closes and proof provenance exists.

## 5. Non-CSS plane without duplicating the entire stack

Store a general stabilizer as `S=(A|B)`. CSS-only tools may operate through symplectic doubling, but the objective must count **Pauli weight**, not raw Hamming weight in `2n`. This allows decoder/search/certifier infrastructure to be shared between CSS and non-CSS codes.

## 6. Syndrome-circuit compiler

A code is not ready for a computer until it has a measurement circuit. The compiler should:

- map checks onto native gates and hardware connectivity;
- minimize depth/crosstalk;
- schedule ancillas and reset;
- generate a detector model;
- measure hook errors and circuit distance;
- produce a backend-specific hardware version.

`code distance` and `circuit distance` must be separate fields.

## 7. Decoder service

The decoder is a runtime service with a hard latency budget. Required profiles include:

- matching / union-find / BP-OSD / neural / hybrid;
- median/p99 latency;
- memory footprint;
- logical error versus physical noise;
- retraining/recalibration policy;
- fallback decoder.

The best code whose syndrome cannot be decoded before the next cycle is not the best code for the machine.

## 8. Logical ISA and fault-tolerant compiler

The logical layer should describe operations independently of a specific code, while the backend chooses the implementation:

- transversal gates;
- lattice surgery / code deformation;
- gauge fixing;
- teleportation / magic-state injection;
- code switching between families when advantageous.

This allows different codes to be used for memory, Clifford operations, and expensive non-Clifford operations.

## 9. Hardware scheduler

At runtime, the system should choose a code profile using current hardware conditions:

`noise bias, erasures/leakage, connectivity, gate/measurement time, reset, crosstalk, decoder latency`.

For that reason I do not recommend building around “one best code”. I recommend an **adaptive code portfolio** with certified CodeIR and a shared proof layer.

## 10. Minimal complete stack

`Hardware calibration -> Noise model -> CodeIR portfolio -> QEC code selector -> Syndrome circuit compiler -> Physical scheduler -> Syndrome stream -> Decoder -> Pauli frame -> Logical ISA -> FT compiler -> Resource manager -> Application`

In parallel, offline:

`Discovery engine -> Structural filters -> Equivalence cache -> Multi-method distance attack -> Exact certifier -> Circuit simulation -> Decoder benchmark -> Hardware qualification -> signed CodeIR release`.

The most important architectural rule is: **no quality metric may lose the information that tells whether it is an estimate, an upper bound, a lower bound, or an exact result**.
