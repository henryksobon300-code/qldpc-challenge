# QUANTUM_CODE_LIBRARY_IMPROVEMENTS_20261012_EN

This package is a technical audit and a set of small, testable components for current issues in qLDPC/qcode-discovery libraries.

This is the English-language replacement for the package previously sent in Polish. The executable Python components are unchanged; only the documentation has been translated and the checksum manifest regenerated.

Contents:
- `FINDINGS_EN.md` — what is a real problem, what has already been fixed upstream, and what remains open.
- `REFERENCE_ARCHITECTURE_EN.md` — target architecture for discovery + verification + runtime QEC + logical computer.
- `symplectic_doubling.py` — clean implementation of stabilizer -> doubled CSS reduction with correct Pauli re-scoring.
- `proof_gate.py` — a hard gate that prevents PARTIAL/heuristic distance from entering downstream tables as exact `d`.
- `resweep_queue.py` — generator for a queue of fresh independent attacks on all non-EXACT records.
- `tests/` — regression tests.

Run:

```bash
pip install numpy pytest
bash run_tests.sh
```

Example resweep queue:

```bash
python resweep_queue.py results/campaign7_publication_merged.jsonl -o resweep_jobs.jsonl
```

Claim boundary: this package does NOT claim that a universally best quantum code exists, and it does not implement a full production RIS/SAT solver. It implements three missing control components and formalizes an architecture in which solvers/refuters can be replaced without losing provenance.
